package com.example.aula7

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
