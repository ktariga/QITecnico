*** Aula 7 ***
- Ainda entendendo a estrutura de componentes do flutter (Widgets);
- Alinhamento com widget Center; MainAxisAlignment para alinhamento de Column;
- Navegando entre telas com Navigator.push.

*** Aula 8 ***
- Criando uma tela de login;
- Importando imagem com Image.asset() (informando a mesma no pubspec.yaml);
- TextEditingController para o atributo controller do widget TextField.

*** Aula 9 ***
- Criando função para validar login;
- AlertDialog / showDialog;
- Navigator.of(context).push().

*** Aula 10 ***
- Checkbox e Radio;
- CheckboxListTile e RadioListTile;
- Métodos do onPressed destes botões.
