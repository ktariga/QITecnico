Projeto final de Desenvolvimento de Aplicativos II 
QI Faculdade & Escola Técnica

NICHO OU SEGMENTO
	O projeto tem como o objetivo a criação de um aplicativo informacional sobre pontos de coletas de ração para animais em condição de vulnerabilidade ou que vivem em ruas, junto de um sistema de auxílio para localizar abrigos de adoção. Tendo assim, um cunho social para o projeto em questão de organizar e auxiliar as pessoas e animais, pelo fato “[..] de acordo com a Organização Mundial de Saúde (OMS), somente no Brasil, cerca de 30 milhões de animais estão abandonados, sendo aproximadamente 20 milhões de cães e 10 milhões de gatos. Em grandes metrópoles, para cada cinco habitantes há um cachorro.” (Instituto Pet Brasil, GOV).
	Assim, vimos que este problema que será abordado pelo projeto ainda está muito em voga em sua demanda, precisando de cada vez mais suporte para auxílios de diversos problemas, e isso entra a oportunidade de criação deste aplicativo.
