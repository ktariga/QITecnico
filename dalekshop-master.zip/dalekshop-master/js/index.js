sessionStorage.description = document.getElementById('description').innerHTML;
sessionStorage.description = document.getElementById('valor').innerHTML;

function resumoCompra(){
    window.location = "carrinho.html";
}

