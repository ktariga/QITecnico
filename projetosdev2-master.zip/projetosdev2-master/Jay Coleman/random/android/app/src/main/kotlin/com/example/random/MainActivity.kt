package com.example.random

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
