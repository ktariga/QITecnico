package com.example.fisiotec

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
