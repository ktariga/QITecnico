-- Mostrar as tabelas existentes
show tables;
-- Mostrar a estrutura de uma tabela
describe clientes;