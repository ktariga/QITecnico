package br.com.andersonchoren.intro_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntroSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
